import sqlite3
import paho.mqtt.client as mqtt

# instellen van mqtt broker ip adres en zijn naam
mqtt_topic = "test_topic"
mqtt_broker_ip = "169.254.107.233"
client = mqtt.Client()

def sendData(data):
	conn = sqlite3.connect('data.db')
	print("Opened database successfully")
	conn.execute("insert into data (toestel_id, aanwezig, CO2, tvco, date,time) values (" + data[0] + ", " + chr(39)  + data[1] + chr(39) +", "  +  data[2] + ", " + data[3] + ", " +chr(39) + data[4] + chr(39) + ", " + chr(39) + data[5] + chr(39) + ")");
	conn.commit()
	print("Records created successfully")
	conn.close()


# kijken of de brokker is geconecteerd 
def on_connect(client, userdata, flags, rc):
	#print("Connected!", str(rc))
	client.subscribe(mqtt_topic)

#dit fucntie wordt opgeroepen telkens als ist gepublished naar de broker
def on_message(client, userdata, msg):
	#print("\nMessage: " + str(msg.payload)+ "\n")
	data = str(msg.payload)
	data = data.split(";")
	for x in range(0,len(data)):
		tussen_variable = data[x].split("=")
		data[x] = tussen_variable[1]
	data[len(data)-1] = data[len(data)-1][0:len(data[len(data)-1])-1]
	sendData(data)

client.on_connect = on_connect
client.on_message = on_message

client.connect(mqtt_broker_ip, 1883)

client.loop_forever()
client.disconnect()

