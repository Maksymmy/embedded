import sqlite3


conn = sqlite3.connect('data.db')
print("Opened database successfully")


conn.execute("insert into data (toestel_id, aanwezig, CO2, tvco, date,time) values (2,'ja', 500,100, '18/4/2020', '17:50')");
conn.commit()
print("Records created successfully")
conn.close()

